﻿var http      = require('http')
var express   = require('express');
var app       = module.exports.app = express();
var server    = http.createServer(app);
var io        = require('socket.io').listen(server);
var port      = process.env.port || 1337;
var clientIDs = []

function log(logMessage){
    console.log(new Date().toLocaleTimeString() + ': ' + logMessage)
}

io.sockets.on('connection', function (socket){
    var clientID = Math.round(Math.random() * 100);
    log('Socket connection. Client id assigned : ' + clientID);
    
    socket.emit('connected', { clientID : clientID });

    socket.on('candidate', function (message) {
        log('ClientID : ' + message.clientID);
        log('ICE candidate : ' + message.data.candidate);
        socket.broadcast.emit('candidate', message);
    });

    socket.on('offer', function (message) {
        log('ClientID : ' + message.clientID);
        log('Offer SDP data : ' + message.sdp);
        socket.broadcast.emit(message.type, message);
    });

    socket.on('answer', function (message) {
        log('ClientID : ' + message.clientID);
        log('Answer SDP data : ' + message.sdp);
        socket.broadcast.emit(message.type, message);
    })
})

app.use(express.static(__dirname + '/Public'))
app.use(express.static(__dirname + '/Js'))
app.get('/', function (req, res){
    res.sendFile(__dirname + '/Html/Default.html')
})

console.log('listening on *:' + port);
server.listen(port);